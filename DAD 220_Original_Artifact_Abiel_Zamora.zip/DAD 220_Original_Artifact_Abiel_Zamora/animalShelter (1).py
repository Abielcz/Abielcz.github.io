from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        # Initializing the MongoClient. This helps to
        # access the MongoDB databases and collections.
        self.client = MongoClient('mongodb://%s:%s@localhost:46764/AAC' % (username, password))
        # where xxxx is your unique port number
        self.database = self.client['AAC']
        self.collection = self.database['animals']

    # Complete this create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
                self.database.animals.insert(data)  # data should be dictionary
                return True
        else:
            return False

    # Create method to implement the R in CRUD.
    def read(self, search):
        if search is not None:
            search_result = self.database.animals.find(search, {"_id":False})
            return search_result
        else:
            return "Invalid Search"
    # Create method to implement the U in CRUD.
    def update(self, search, update):
        if search is not None and update is not None:
            result = self.collection.update_one(search, {"$set": update})
            return result.modified_count
        else:
            return "Invalid update"
    # Create method to implement the D in CRUD.
    def delete(self, search):
        if search is not None:
            result = self.collection.delete_one(search)
            return result.deleted_count
        else:
            return "Invalid delete"
