//Creating Monkey Class, Abiel Angel Zamora, 10/03/2021
public class Monkey extends RescueAnimal{
	private String bodyLength, tailLength, height, species;
	
	public Monkey (String bodyLength, String tailLength, String height, String weight, String species, String name, String acquisitionDate, String acquisitionCountry, String trainingStatus, String inServiceCountry) {
		setBodyLength(bodyLength);
		setTailLength(tailLength);
		setHeight(height);
		setWeight(weight);
		setSpecies(species);
		setName(name);
		setAcquisitionDate(acquisitionDate);
		setAcquisitionLocation(acquisitionCountry);
		setTrainingStatus(trainingStatus);
		setInServiceCountry(inServiceCountry);
	}
	public String getBodyLength() {
		return bodyLength;
	}
	public void setBodyLength(String monkeyBodyLength) {
		bodyLength = monkeyBodyLength;
	}
	public String getTailLength() {
		return tailLength;
	}
	public void setTailLength(String monkeyTailLength) {
		tailLength = monkeyTailLength;
	}
	public String getHeight() {
		return height;
	}
	public void setHeight(String monkeyHeight) {
		height = monkeyHeight;
	}
	public String getSpecies() {
		return species;
	}
	public void setSpecies(String monkeySpecies) {
		species = monkeySpecies;
	}
	public static Object getInserviceCountry() {
		// TODO Auto-generated method stub
		return null;
	}
}
