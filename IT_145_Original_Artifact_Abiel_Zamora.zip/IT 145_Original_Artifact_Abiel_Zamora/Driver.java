//Creating loop, Abiel Angel Zamora, 10/03/2021
import java.util.ArrayList;
import java.util.Scanner;

public class Driver {
    private static ArrayList<Dog> dogList = new ArrayList<Dog>();
    private static ArrayList<Monkey> monkeyList = new ArrayList<Monkey>();

    @SuppressWarnings("unlikely-arg-type")
	public static void main(String[] args) {


        initializeDogList();
        initializeMonkeyList();
        
       Scanner input = new Scanner (System.in);
       String option; {
       displayMenu();
       option = input.next();
       if(option.equals (1)) {
    	   intakeNewDog(input);
       }
       else if(option.equals (2)) {
    	   intakeNewMonkey(input);
       }
       else if(option.equals (3)) {
    	   reserveAnimal(input);
       }
       else if (option.equals (4)) {
    	   printAnimals();
       }
       else if (option.equals (5)) {
    	   printAnimals();
       }
       else if (option.equals (6)) {
    	   printAnimals();
       }
       else if(option.equals ('q')) {
    	   System.out.print("Exiting...");
       }
       else {
    	   System.out.println("Inalvid option.");
       }
       }while(option.equals (6));
       
    }

    // This method prints the menu options
    public static void displayMenu() {
        System.out.println("\n\n");
        System.out.println("\t\t\t\tRescue Animal System Menu");
        System.out.println("[1] Intake a new dog");
        System.out.println("[2] Intake a new monkey");
        System.out.println("[3] Reserve an animal");
        System.out.println("[4] Print a list of all dogs");
        System.out.println("[5] Print a list of all monkeys");
        System.out.println("[6] Print a list of all animals that are not reserved");
        System.out.println("[q] Quit application");
        System.out.println();
        System.out.println("Enter a menu selection");
    }


    // Adds dogs to a list for testing
    public static void initializeDogList() {
        Dog dog1 = new Dog("Spot", "German Shepherd", "male", "1", "25.6", "05-12-2019", "United States", "intake", false, "United States");
        Dog dog2 = new Dog("Rex", "Great Dane", "male", "3", "35.2", "02-03-2020", "United States", "Phase I", false, "United States");
        Dog dog3 = new Dog("Bella", "Chihuahua", "female", "4", "25.6", "12-12-2019", "Canada", "in service", true, "Canada");

        dogList.add(dog1);
        dogList.add(dog2);
        dogList.add(dog3);
    }


    // Adds monkeys to a list for testing
    //Optional for testing
    public static void initializeMonkeyList() {    	
    	Monkey m1 = new Monkey ("Buddy","Squirrel Monkey","male","4","16.2","10-03-2021","united states","intake","false","United States");
    	Monkey m2 = new Monkey ("Honcho","Spider Monkey","male","6","24","10-02-2021","united states","intake","false","United States");		
    	Monkey m3 = new Monkey ("Buddy","Capuchin Monkey","female","3","14.5","10-01-2021","canada","intake","false","Canada");
    monkeyList.add(m1);
    monkeyList.add(m2);
    monkeyList.add(m3);
    }


    // Complete the intakeNewDog method
    // The input validation to check that the dog is not already in the list
    // is done for you
    public static void intakeNewDog(Scanner scanner) {
        System.out.println("What is the dog's name?");
        String name = scanner.nextLine();
        for(Dog dog: dogList) {
            if(dog.getName().equalsIgnoreCase(name)) {
                System.out.println("\n\nThis dog is already in our system\n\n");
                return; //returns to menu
            }
        }
        System.out.println("What is dog breed?");
        String breed = scanner.nextLine();
        
        System.out.println("What is dog gender?");
        String gender = scanner.nextLine();
        
        System.out.println("What is dog age?");
        String age = scanner.nextLine();
        
        System.out.println("What is dog weight?");
        String weight = scanner.nextLine();
        
        System.out.println("What is dog acquisition date?");
        String acquisitionDate = scanner.nextLine();
        
        System.out.println("What is dog acquisiton country?");
        String acquisitionCountry = scanner.nextLine();
        
        System.out.println("Is dog reserved?");
        boolean reserved = scanner.nextBoolean();scanner.nextLine();
        
        System.out.println("What is dog in service Country?");
        String inServiceCountry = scanner.nextLine();
        
        System.out.println("What is dog training status?");
        String trainingStatus = scanner.nextLine();

        Dog(name, breed, gender, age, weight, acquisitionDate, acquisitionCountry, reserved, inServiceCountry, trainingStatus);
        
        }

        // Add the code to instantiate a new dog and add it to the appropriate list
    private static void Dog(String name, String breed, String gender, String age, String weight, String acquisitionDate,
			String acquisitionCountry, boolean reserved, String inServiceCountry, String trainingStatus) {
		// TODO Auto-generated method stub
		
	}
        
    // Complete intakeNewMonkey
	//Instantiate and add the new monkey to the appropriate list
        // For the project submission you must also  validate the input
	// to make sure the monkey doesn't already exist and the species type is allowed
        public static void intakeNewMonkey(Scanner scanner) {
            System.out.println("The method intakeNewMonkey needs to be implemented");
        System.out.println("What is monkey name?");
        String name = scanner.nextLine();{
        	if(Monkey.getName().equalsIgnoreCase(name)) {
        		System.out.print("This monkey already exists");
        	}
        }
        
        System.out.println("What is monkey species?");
        String species = scanner.nextLine();
        
        System.out.println("What is monkey gender?");
        String gender = scanner.nextLine();
        
        System.out.println("What is monkey age?");
        String age = scanner.nextLine();
        
        System.out.println("What is monkey weight?");
        String weight = scanner.nextLine();
        
        System.out.println("What is monkey acquisition date?");
        String acquisitionDate = scanner.nextLine();
        
        System.out.println("What is monkey acquisiton country?");
        String acquisitionCountry = scanner.nextLine();
        
        System.out.println("Is monkey reserved?");
        boolean reserved = scanner.nextBoolean();scanner.nextLine();
        
        System.out.println("What is monkey in service country?");
        String inServiceCountry = scanner.nextLine();
        
        System.out.println("What is monkey training status?");
        String trainingStatus = scanner.nextLine();

        Monkey(name, species, gender, age, weight, acquisitionDate, acquisitionCountry, reserved, inServiceCountry, trainingStatus);
        
        }

        private static void Monkey(String name, String species, String gender, String age, String weight,
			String acquisitionDate, String acquisitionCountry, boolean reserved, String inServiceCountry,
			String trainingStatus) {
		// TODO Auto-generated method stub
		
	}

		// Complete reserveAnimal
        // You will need to find the animal by animal type and in service country
        public static void reserveAnimal(Scanner scanner) {
            System.out.println("The method reserveAnimal needs to be implemented");
            System.out.println("What is animal type?");
            String animalType = scanner.nextLine();
            System.out.println("What is in service country?");
            String inServiceCountry = scanner.nextLine();
            if(animalType.equals("dog"));
            for(Dog dog: dogList);{
            	Dog.getInServiceCountry().equals(inServiceCountry);{
            	Dog.setReserved(true);
            }
            }
            if(animalType.equals("monkey"));
            for(Monkey monkey: monkeyList);{
            	Monkey.getInserviceCountry().equals(inServiceCountry);{
            	Monkey.setReserved(true);
            }
            }
            System.out.println("No" + animalType + "found in" + inServiceCountry);
        }

        // Complete printAnimals
        // Include the animal name, status, acquisition country and if the animal is reserved.
	// Remember that this method connects to three different menu items.
        // The printAnimals() method has three different outputs
        // based on the listType parameter
        // dog - prints the list of dogs
        // monkey - prints the list of monkeys
        // available - prints a combined list of all animals that are
        // fully trained ("in service") but not reserved 
	// Remember that you only have to fully implement ONE of these lists. 
	// The other lists can have a print statement saying "This option needs to be implemented".
	// To score "exemplary" you must correctly implement the "available" list.
        public static void printAnimals() {
            System.out.println("The method printAnimals needs to be implemented");
            Object animalType = null;
			if(animalType.equals("dog"));{
			System.out.println("All dogs");
			for(Dog dog : dogList);
			Object dog = null;
			System.out.println(dog.toString());
			}
			if(animalType.equals("monkey"));{
			System.out.println("All monkeys");
			for(Monkey monkey : monkeyList);
			Object monkey = null;
			System.out.println(monkey.toString());
			}
			if(animalType.equals("availible"));{
				System.out.println("All dogs availible and training");
				for(Dog dog : dogList);
				if(Dog.getTrainingStatus().equals("in service"));
				Object dog = null;
				System.out.println(dog.toString());
			}
			if(animalType.equals("availible"));{
				System.out.println("All monkeys availible and training");
				for(Monkey monkey : monkeyList);
				if(Monkey.getTrainingStatus().equals("in service"));
				Object monkey = null;
				System.out.println(monkey.toString());
				}
        	}
		}
       

