# Abiel A. Zamora, abiel.zamora@snhu.edu, 02/6/2024, version 2, class that ensures that creates common attributes for
# all rescue animals

class RescueAnimal:
    # Constructor
    def __init__(self):
        # Initializes attributes to all rescue animals
        self.name = ""
        self.animalType = ""
        self.gender = ""
        self.age = ""
        self.weight = ""
        self.acquisitionDate = ""
        self.acquisitionCountry = ""
        self.reserved = False
        self.trainingStatus = ""
        self.inServiceCountry = ""
