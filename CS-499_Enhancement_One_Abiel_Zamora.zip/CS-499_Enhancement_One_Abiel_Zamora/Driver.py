# Abiel A. Zamora, abiel.zamora@snhu.edu, 02/6/2024, version 2, menu interface with various options that allows users to
# manage and add data related to rescue animals

# Imports to grab information from these classes
from Monkey import Monkey
from Dog import Dog


# Method to display menu options
def display_menu():
    print("\n\n\t\t\t\tRescue Animal System Menu")
    print("[1] Intake a new dog")
    print("[2] Intake a new monkey")
    print("[3] Reserve an animal")
    print("[4] Show list of all dogs")
    print("[5] Show list of all monkeys")
    print("[6] Show list of all animals")
    print("[q] Quit application")
    print("\nEnter a menu selection")


# Class to manage system
class Driver:
    def __init__(self):
        # Lists for dogs, monkeys, and reptiles
        self.dog_list = []
        self.monkey_list = []

    # Method to initialize dog list with test data
    def initialize_dog_list(self):
        # Creating instances of dogs and adding them to the dog list
        dog1 = Dog("Spot", "German Shepherd", "male", "1", "25.6", "05-12-2019", "United States", "intake", False,
                   "United States")
        dog2 = Dog("Rex", "Great Dane", "male", "3", "35.2", "02-03-2020", "United States", "Phase I", False,
                   "United States")
        dog3 = Dog("Bella", "Chihuahua", "female", "4", "25.6", "12-12-2019", "Canada", "in service", True, "Canada")
        self.dog_list.extend([dog1, dog2, dog3])

    # Method to initialize monkey list with test data
    def initialize_monkey_list(self):
        # Creating instances of monkeys and adding them to the dog list
        m1 = Monkey("Buddy", "Squirrel Monkey", "male", "4", "16", "30", "20", "19", "10-03-2021", "united states",
                    "intake", False, "United States")
        m2 = Monkey("Honcho", "Spider Monkey", "male", "6", "24", "30", "28", "25", "10-02-2021", "united states",
                    "intake", False, "United States")
        m3 = Monkey("Buddy", "Capuchin Monkey", "female", "3", "30", "14", "18", "16", "10-01-2021", "canada", "intake",
                    False, "Canada")
        self.monkey_list.extend([m1, m2, m3])

    # Method to intake a new dog
    def intake_new_dog(self):
        # Asks user for dog info and creates a new dog instance
        name = input("What is the dog's name? ")
        for dog in self.dog_list:
            if dog.name.lower() == name.lower():
                print("\n\nThis dog is already in our system\n\n")
                return

        breed = input("What is dog breed?")
        gender = input("What is dog gender?")
        age = input("What is dog age?")
        weight = input("What is dog weight?")
        acquisitionDate = input("What is dog acquisition date?")
        acquisitionCountry = input("What is dog acquisition country?")
        trainingStatus = input("What is dog training status?")
        inServiceCountry = input("What is dog in service country?")

        # Creating a new dog instance and adding it to the list
        new_dog = Dog(name, breed, gender, age, weight, acquisitionDate, acquisitionCountry, trainingStatus, False,
                      inServiceCountry)
        self.dog_list.append(new_dog)
        print("Dog has been stored.")

    # Method to intake a new monkey
    def intake_new_monkey(self):
        # Asks user for monkey info and creates a new monkey instance
        name = input("What is monkey name? ")
        for monkey in self.monkey_list:
            if monkey.name.lower() == name.lower():
                print("This monkey already exists")
                return

        species = input("What is monkey species?")
        gender = input("What is monkey gender?")
        age = input("What is monkey age?")
        weight = input("What is monkey weight?")
        bodyLength = input("What is monkey body length?")
        tailLength = input("What is monkey tail length?")
        height = input("What is monkey height?")
        acquisitionDate = input("What is monkey acquisition date?")
        acquisitionCountry = input("What is monkey acquisition country?")
        trainingStatus = input("What is monkey training status?")
        inServiceCountry = input("What is monkey in service country?")

        # Creating a new monkey instance and adding it to the list
        new_monkey = Monkey(name, species, gender, age, weight, acquisitionDate, acquisitionCountry, trainingStatus,
                            False, inServiceCountry, bodyLength, tailLength, height)
        self.monkey_list.append(new_monkey)
        print("Monkey has been stored.")

    # Method to reserve an animal
    def reserve_animal(self):
        # Asks user for animal info to reserve
        animal_type = input("What is animal name?")
        in_service_country = input("What is in service country?")
        # Checking for animal type and reserving if found
        if animal_type.lower() == "dog":
            for dog in self.dog_list:
                if dog.inServiceCountry.lower() == in_service_country.lower():
                    dog.reserved = True
                    print("Dog successfully reserved.")
                    return
        elif animal_type.lower() == "monkey":
            for monkey in self.monkey_list:
                if monkey.inServiceCountry.lower() == in_service_country.lower():
                    monkey.reserved = True
                    print("Monkey successfully reserved.")
                    return

    # Method to print all animals
    def print_animals(self):
        pass

    # Method to print all dogs
    def print_dogs(self):
        print("All dogs:")
        for dog in self.dog_list:
            print(vars(dog))
        pass

    # Method to print all monkeys
    def print_monkeys(self):
        print("All monkeys:")
        for monkey in self.monkey_list:
            print(vars(monkey))
        pass


# Main function
def main():
    # Driver class instance
    driver = Driver()
    # Initializing lists with test data
    driver.initialize_dog_list()
    driver.initialize_monkey_list()

    option = ""
    # Displays menu until user chooses to quit
    while option != "q":
        display_menu()
        option = input()
        # Handles user options
        if option == "1":
            driver.intake_new_dog()
        elif option == "2":
            driver.intake_new_monkey()
        elif option == "3":
            driver.reserve_animal()
        elif option == "4":
            driver.print_dogs()
        elif option == "5":
            driver.print_monkeys()
        elif option == "6":
            driver.print_animals()
        elif option.lower() == "q":
            print("Exiting...")
        else:
            print("Invalid option.")


if __name__ == "__main__":
    main()
