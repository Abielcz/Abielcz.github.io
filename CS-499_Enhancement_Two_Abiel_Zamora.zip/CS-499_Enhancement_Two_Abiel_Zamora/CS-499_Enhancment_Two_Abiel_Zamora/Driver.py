# Abiel A. Zamora, abiel.zamora@snhu.edu, 02/6/2024, version 2, menu interface with various options that allows users to
# manage and add data related to rescue animals

# Imports to grab information from these classes
from Monkey import Monkey
from Dog import Dog


# Method to display menu options
def display_menu():
    print("\n\n\t\t\t\tRescue Animal System Menu")
    print("[1] Intake a new dog")
    print("[2] Intake a new monkey")
    print("[3] Reserve an animal")
    print("[4] Show list of all dogs")
    print("[5] Show list of all monkeys")
    print("[6] Show list of all animals")
    print("[q] Quit application")
    print("\nEnter a menu selection")


# Class to manage system
class Driver:
    def __init__(self):
        # Dictionary for dogs, monkeys, and reptiles *Updated 02/11/24 from list to dict which increases time complexity
        # to O(1) as hash tables are being used *
        self.dog_dict = {}
        self.monkey_dict = {}

    # Method to initialize dog dictionary with test data *Updated 02/09/24 from list to dict*
    def initialize_dog_dict(self):
        # Creating instances of dogs and adding them to the dog dictionary
        self.dog_dict["Spot"] = Dog("Spot", "German Shepherd", "male", "1", "25.6", "05-12-2019", "United States",
                                    "intake", False, "United States")
        self.dog_dict["Rex"] = Dog("Rex", "Great Dane", "male", "3", "35.2", "02-03-2020", "United States", "Phase I",
                                   False, "USA")
        self.dog_dict["Bella"] = Dog("Bella", "Chihuahua", "female", "4", "25.6", "12-12-2019", "Canada", "in service",
                                     True, "Canada")

    # Method to initialize monkey dictionary with test data *Updated 02/11/24 from list to dict which increases time
    # complexity to O(1) as hash tables are being used *
    def initialize_monkey_dict(self):
        # Creating instances of monkeys and adding them to the monkey dictionary
        self.monkey_dict["Buddy"] = Monkey("Buddy", "Squirrel Monkey", "male", "4", "16", "30", "20", "19",
                                           "10-03-2021", "united states", "intake", False, "United States")
        self.monkey_dict["Honcho"] = Monkey("Honcho", "Spider Monkey", "male", "6", "24", "30", "28", "25",
                                            "10-02-2021", "united states", "intake", False, "United States")
        self.monkey_dict["Buddy2"] = Monkey("Buddy", "Capuchin Monkey", "female", "3", "30", "14", "18", "16",
                                            "10-01-2021", "canada", "intake", False, "Canada")

    # Method to intake a new dog
    def intake_new_dog(self):
        # Asks user for dog info and creates a new dog instance
        name = input("What is the dog's name? ")
        if name.lower() in self.dog_dict:
            print("\n\nThis dog is already in our system\n\n")
            return

        breed = input("What is dog breed?")
        gender = input("What is dog gender?")
        age = input("What is dog age?")
        weight = input("What is dog weight?")
        acquisitionDate = input("What is dog acquisition date?")
        acquisitionCountry = input("What is dog acquisition country?")
        trainingStatus = input("What is dog training status?")
        inServiceCountry = input("What is dog in service country?")

        # Creating a new dog instance and adding it to the dictionary *Updated 02/09/24 from list to dict which increase
        # time complexity to O(1) as hash tables are being used *
        new_dog = Dog(name, breed, gender, age, weight, acquisitionDate, acquisitionCountry, trainingStatus, False,
                      inServiceCountry)
        self.dog_dict[name.lower()] = new_dog
        print("Dog has been stored.")

    # Method to intake a new monkey
    def intake_new_monkey(self):
        # Asks user for monkey info and creates a new monkey instance
        name = input("What is monkey name? ")
        if name.lower() in self.monkey_dict:
            print("This monkey already exists")
            return

        species = input("What is monkey species?")
        gender = input("What is monkey gender?")
        age = input("What is monkey age?")
        weight = input("What is monkey weight?")
        bodyLength = input("What is monkey body length?")
        tailLength = input("What is monkey tail length?")
        height = input("What is monkey height?")
        acquisitionDate = input("What is monkey acquisition date?")
        acquisitionCountry = input("What is monkey acquisition country?")
        trainingStatus = input("What is monkey training status?")
        inServiceCountry = input("What is monkey in service country?")

        # Creating a new monkey instance and adding it to the dictionary *Updated 02/09/24 from list to dict which
        # increases time complexity to O(1) as hash tables are being used *
        new_monkey = Monkey(name, species, gender, age, weight, acquisitionDate, acquisitionCountry, trainingStatus,
                            False, inServiceCountry, bodyLength, tailLength, height)
        self.monkey_dict[name.lower()] = new_monkey
        print("Monkey has been stored.")

    # Method to reserve an animal
    def reserve_animal(self):
        # Asks user for animal info to reserve
        animal_name = input("What is animal name?")
        # validates user input for correct input *Added 02/09/2024*
        if animal_name not in self.dog_dict and animal_name not in self.monkey_dict:
            print("Animal not found.")
            return

        # Asks user for in service country
        in_service_country = input("What is in service country?")

        # Reserve animal based on name and service country
        if animal_name in self.dog_dict:
            # Validates dog by given service country
            if self.dog_dict[animal_name].inServiceCountry == in_service_country:
                # Reserves dog or tells user not available
                self.dog_dict[animal_name].reserved = False
                print("Dog successfully reserved.")
            else:
                print("Dog not available in given country.")
        elif animal_name in self.monkey_dict:
            # Validates monkey by given service country
            if self.monkey_dict[animal_name].inServiceCountry == in_service_country:
                # Reserves monkey or tells user not available
                self.monkey_dict[animal_name].reserved = False
                print("Monkey successfully reserved.")
            else:
                print("Monkey not available in given country.")

    # Method to print all animals
    def print_animals(self):
        print("All dogs:")
        for dog in self.dog_dict.values():
            print(vars(dog))
        print("All monkeys:")
        for monkey in self.monkey_dict.values():
            print(vars(monkey))
        pass

    # Method to print all dogs
    def print_dogs(self):
        print("All dogs:")
        for dog in self.dog_dict.values():
            print(vars(dog))
        pass

    # Method to print all monkeys
    def print_monkeys(self):
        print("All monkeys:")
        for monkey in self.monkey_dict.values():
            print(vars(monkey))
        pass


# Main function
def main():
    # Driver class instance
    driver = Driver()
    # Initializing dictionary with test data *Updated 02/09/24 from list to dict*
    driver.initialize_dog_dict()
    driver.initialize_monkey_dict()

    option = ""
    # Displays menu until user chooses to quit
    while option != "q":
        display_menu()
        option = input()
        # Handles user options
        if option == "1":
            driver.intake_new_dog()
        elif option == "2":
            driver.intake_new_monkey()
        elif option == "3":
            driver.reserve_animal()
        elif option == "4":
            driver.print_dogs()
        elif option == "5":
            driver.print_monkeys()
        elif option == "6":
            driver.print_animals()
        elif option.lower() == "q":
            print("Exiting...")
        else:
            print("Invalid option.")


if __name__ == "__main__":
    main()
