# Abiel A. Zamora, abiel.zamora@snhu.edu, 02/6/2024, version 2, class that ensures that each Dog object is
# initialized with relevant attributes

# Imports to grab information from this classes
from RescueAnimal import RescueAnimal


# Dog class inherits from RescueAnimal class
class Dog(RescueAnimal):
    # Constructor for dog object
    def __init__(self, name, breed, gender, age, weight, acquisitionDate, acquisitionCountry, trainingStatus, reserved,
                 inServiceCountry):
        super().__init__()
        # Initializes attributes specific to this class
        self.name = name
        self.breed = breed
        self.gender = gender
        self.age = age
        self.weight = weight
        self.acquisitionDate = acquisitionDate
        self.acquisitionCountry = acquisitionCountry
        self.trainingStatus = trainingStatus
        self.reserved = reserved
        self.inServiceCountry = inServiceCountry
