#! /bin/bash
# Script to change the ownership of the default workspace directory in Codio to the mysql service account
# to enable DAD-220 students to write files out to disk within mysql and do so without receiving a 
# file permission error.
#
# Written by: Bryan King b.king2@snhu.edu
# Date: 29-October-2019
cd ..
sudo chown mysql:mysql workspace
printf "%s\n"
printf '\e[1;36;60m Updated ownership of workspace to mysql\e[m\n'
printf "%s\n" 
exit
